// server/src/ai/recommendationEngine.ts
import * as tf from '@tensorflow/tfjs-node';
import { User, Activity } from '../models';
import { getLocalSustainabilityOptions } from '../services/locationService';

export class RecommendationEngine {
  private model: tf.LayersModel | null = null;
  
  constructor() {
    this.loadModel();
  }
  
  private async loadModel() {
    try {
      // Load the pre-trained model
      this.model = await tf.loadLayersModel('file://./src/ai/models/recommendation_model/model.json');
      console.log('AI recommendation model loaded successfully');
    } catch (error) {
      console.error('Failed to load recommendation model:', error);
    }
  }
  
  /**
   * Generate user feature vector based on activity history and profile
   */
  private async generateUserFeatures(userId: string): Promise<tf.Tensor> {
    // Get user data and activity history
    const user = await User.findById(userId).lean();
    const activities = await Activity.find({ userId }).sort({ date: -1 }).limit(100).lean();
    
    // Extract features: activity frequencies, geographical context, user preferences
    const transportFrequency = activities.filter(a => a.category === 'transport').length / activities.length;
    const homeFrequency = activities.filter(a => a.category === 'home').length / activities.length;
    const foodFrequency = activities.filter(a => a.category === 'food').length / activities.length;
    const shoppingFrequency = activities.filter(a => a.category === 'shopping').length / activities.length;
    
    // Calculate average footprint by category
    const transportFootprint = activities
      .filter(a => a.category === 'transport')
      .reduce((sum, a) => sum + a.carbonFootprint, 0) / 
      (activities.filter(a => a.category === 'transport').length || 1);
    
    // User preferences and location features
    const costSensitivity = user.preferences?.costSensitivity || 0.5;
    const effortTolerance = user.preferences?.effortTolerance || 0.5;
    const hasPublicTransport = user.location?.hasPublicTransport ? 1 : 0;
    
    // Combine all features into a tensor
    return tf.tensor2d([
      [
        transportFrequency, homeFrequency, foodFrequency, shoppingFrequency,
        transportFootprint, /* other features */
        costSensitivity, effortTolerance, hasPublicTransport
      ]
    ]);
  }
  
  /**
   * Score recommendations for a specific user
   */
  public async scoreRecommendationsForUser(userId: string) {
    if (!this.model) {
      throw new Error('Recommendation model not loaded');
    }
    
    // Get all available recommendations
    const allRecommendations = await this.getAllRecommendations();
    
    // Generate user features
    const userFeatures = await this.generateUserFeatures(userId);
    
    // Score each recommendation
    const scores = [];
    
    for (const recommendation of allRecommendations) {
      // Convert recommendation to feature vector
      const recFeatures = this.recommendationToFeatures(recommendation);
      
      // Combine user and recommendation features
      const combinedFeatures = tf.concat([userFeatures, recFeatures], 1);
      
      // Predict score using the model
      const scoreTensor = this.model.predict(combinedFeatures) as tf.Tensor;
      const score = (await scoreTensor.data())[0];
      
      scores.push({
        id: recommendation.id,
        score: score
      });
      
      // Clean up tensors
      scoreTensor.dispose();
    }
    
    // Clean up and return sorted recommendations
    userFeatures.dispose();
    return scores.sort((a, b) => b.score - a.score);
  }
  
  // Other helper methods...
}

// Export singleton instance
export const recommendationEngine = new RecommendationEngine();
