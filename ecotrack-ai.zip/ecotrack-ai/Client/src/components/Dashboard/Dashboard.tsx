// client/src/components/Dashboard/Dashboard.tsx
import React, { useState, useEffect } from 'react';
import { 
  Grid, Paper, Typography, Box, CircularProgress, useTheme
} from '@mui/material';
import { 
  CarbonFootprintChart, ActivityBreakdown, RecommendationCard,
  TeamProgress, AchievementsList
} from '../components';
import { fetchUserFootprint, fetchRecommendations } from '../../services/api';
import { useAuth } from '../../context/AuthContext';

const Dashboard: React.FC = () => {
  const theme = useTheme();
  const { user } = useAuth();
  const [loading, setLoading] = useState(true);
  const [footprintData, setFootprintData] = useState(null);
  const [recommendations, setRecommendations] = useState([]);
  
  useEffect(() => {
    const loadData = async () => {
      setLoading(true);
      try {
        // Fetch user's carbon footprint data
        const footprint = await fetchUserFootprint(user.id);
        setFootprintData(footprint);
        
        // Fetch personalized recommendations
        const recs = await fetchRecommendations(user.id);
        setRecommendations(recs);
      } catch (error) {
        console.error('Error loading dashboard data:', error);
      } finally {
        setLoading(false);
      }
    };
    
    loadData();
  }, [user.id]);
  
  if (loading) {
    return (
      <Box display="flex" justifyContent="center" alignItems="center" minHeight="80vh">
        <CircularProgress />
      </Box>
    );
  }
  
  return (
    <Box sx={{ flexGrow: 1, p: 3 }}>
      <Grid container spacing={3}>
        {/* Header section */}
        <Grid item xs={12}>
          <Typography variant="h4" gutterBottom>
            Your Carbon Footprint Dashboard
          </Typography>
        </Grid>
        
        {/* Current footprint overview */}
        <Grid item xs={12} md={8}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Your Carbon Footprint
            </Typography>
            <Box sx={{ display: 'flex', alignItems: 'center', mb: 2 }}>
              <Typography variant="h3">
                {footprintData?.total.toFixed(1)}
              </Typography>
              <Typography variant="body1" sx={{ ml: 1 }}>
                kg CO₂e / month
              </Typography>
            </Box>
            <CarbonFootprintChart data={footprintData?.history || []} />
          </Paper>
        </Grid>
        
        {/* Activity breakdown */}
        <Grid item xs={12} md={4}>
          <Paper sx={{ p: 2, height: '100%' }}>
            <Typography variant="h6" gutterBottom>
              Activity Breakdown
            </Typography>
            <ActivityBreakdown data={footprintData?.byCategory || {}} />
          </Paper>
        </Grid>
        
        {/* AI Recommendations */}
        <Grid item xs={12}>
          <Typography variant="h5" gutterBottom>
            Personalized Recommendations
          </Typography>
          <Grid container spacing={2}>
            {recommendations.map((rec) => (
              <Grid item xs={12} sm={6} md={4} key={rec.id}>
                <RecommendationCard recommendation={rec} />
              </Grid>
            ))}
          </Grid>
        </Grid>
        
        {/* Team Progress & Achievements */}
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Team Progress
            </Typography>
            <TeamProgress />
          </Paper>
        </Grid>
        
        <Grid item xs={12} md={6}>
          <Paper sx={{ p: 2 }}>
            <Typography variant="h6" gutterBottom>
              Your Achievements
            </Typography>
            <AchievementsList />
          </Paper>
        </Grid>
      </Grid>
    </Box>
  );
};

export default Dashboard;
